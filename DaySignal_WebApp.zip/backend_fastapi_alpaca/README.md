# DaySignal Backend (Live)

## 1) Alpaca keys
Create keys at Alpaca: https://alpaca.markets/data

## 2) Install & run
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

Create .env with:
ALPACA_API_KEY=...
ALPACA_API_SECRET=...
RISK_EUR=25

Run:
uvicorn server:app --host 0.0.0.0 --port 8000

Test:
http://localhost:8000/today

## Hosting
- Local (same Wi‑Fi): works only at home.
- Internet hosting (Render/Railway/Fly): works anywhere.
